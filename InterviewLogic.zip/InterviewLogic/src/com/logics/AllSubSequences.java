package com.logics;

public class AllSubSequences {

	public static void main(String[] args) {
		
		////op ->a, b, c, ab, bc, ac, abc...
		
		String in = "abc";
		
	}
}
