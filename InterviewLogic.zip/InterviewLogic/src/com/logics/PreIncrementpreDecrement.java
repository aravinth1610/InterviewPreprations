package com.logics;

public class PreIncrementpreDecrement {

	public static void main(String[] args) {
		
		//op ->{7, 1, 6, 2, 5, 3, 4}
		
		/*
		 *  O.p -> 9 18 11 8 20 4 100  
		*/
		
		Integer[] in={1, 6, 4, 3, 7,5, 2};
		int[] in2=   {9,4,20,18,11,8,100,2,22};
	}
}
