package com.logics;

public class AllPermutations {

	public static void main(String[] args) {
		/*
		 * ABC
           ACB
           BAC
           BCA
           CAB
           CBA
		 */
		
		String In="ABC";
	}
}
